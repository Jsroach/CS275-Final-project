package com.example.criminalintent;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemListFragment extends Fragment {

    private ItemAdapter mAdapterItem;
    private RecyclerView mItemRecyclerView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View Itemview = inflater.inflate(R.layout.fragment_item_list, container, false);
        mItemRecyclerView = (RecyclerView) Itemview
                .findViewById(R.id.item_recycler_view);
        mItemRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUITwo();
        return Itemview;
    }
    @Override
    public void onResume() {
        super.onResume();
        updateUITwo();
    }

    private void updateUITwo() {
        ItemLab itemLab = ItemLab.getItem(getActivity());
        List<Item> items = itemLab.getItems();

        if (mAdapterItem == null ) {
            mAdapterItem = new ItemAdapter(items);
            mItemRecyclerView.setAdapter(mAdapterItem);
        } else {

            //mAdapterItem.notifyDataSetChanged();
        }
    }


    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        private Item mDefense;

        private TextView mTitleTextViewItem;
        private TextView mPriceTextViewItem;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_item, parent, false));
            itemView.setOnClickListener(this);


            mTitleTextViewItem = (TextView) itemView.findViewById(R.id.item_title);
            mPriceTextViewItem = (TextView) itemView.findViewById(R.id.item_price);
        }


        public void bindTwo(Item item) {
            mDefense = item;
            mTitleTextViewItem.setText(mDefense.getTitle());
            mPriceTextViewItem.setText(mDefense.getPrice());
        }

        @Override
        public void onClick(View view) {

            if(mDefense!= null) {
                Intent intent = CrimeActivity.newIntent(getActivity(), mDefense.getId());
                startActivity(intent);

            }

        }

    }


    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {
        private List<Item> mDefense;


        public ItemAdapter(List<Item> items) {
            mDefense = items;
        }


        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        public void onBindViewHolder(ItemListFragment.ItemHolder holder, int position) {
            Item item = mDefense.get(position);
            holder.bindTwo(item);
        }


        public int getItemCount() {
            return mDefense.size();
        }
    }

}
