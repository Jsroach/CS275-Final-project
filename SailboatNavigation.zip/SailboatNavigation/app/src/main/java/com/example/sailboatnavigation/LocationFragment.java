package com.example.sailboatnavigation;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

import java.util.UUID;

public class LocationFragment extends Fragment {
    private static final String ARG_Location_ID = "Location_id";

    private Location mLocation;
    private TextView mTitleField;
    private TextView mLocationNumber;
    private TextView mXCoordinate;
    private TextView mYCoordinate;
    private TextView mWeapon;
    private TextView mDistance;
    private Button mDateButton;
    private CheckBox mSolvedCheckBox;
    public static LocationFragment newInstance(UUID LocationId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_Location_ID, LocationId);
        LocationFragment fragment = new LocationFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID LocationId = (UUID) getArguments().getSerializable(ARG_Location_ID);
        mLocation = LocationLab.get(getActivity()).getLocation(LocationId);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_location, container, false);

        /*mTitleField = (EditText) v.findViewById(R.id.Location_title);
        mTitleField.setText(mLocation.getTitle());
        mTitleField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence s, int start, int count, int after) {
                // This space intentionally left blank
            }
            @Override
            public void onTextChanged(
                    CharSequence s, int start, int before, int count) {
                mLocation.setTitle(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
                // This one too
            }
        });*/
        mTitleField = (TextView) v.findViewById(R.id.Location_title);
        mTitleField.setText(mLocation.getTitle());
        mLocationNumber = (TextView) v.findViewById(R.id.Location_number);
        mLocationNumber.setText(mLocation.getLocationNumber());

        mDistance = (TextView) v.findViewById(R.id.distance);
        mDistance.setText(mLocation.getDistance());

        mXCoordinate = (TextView) v.findViewById(R.id.xCoordinate);
        mXCoordinate.setText(mLocation.getXCoordinate());

        mYCoordinate = (TextView) v.findViewById(R.id.yCoordinate);
        mYCoordinate.setText(mLocation.getYCoordinate());

        mWeapon = (TextView) v.findViewById(R.id.weapon);
        mWeapon.setText(mLocation.getWeapon());

        //mDateButton = (Button) v.findViewById(R.id.Location_date);
        //mDateButton.setText(mLocation.getDate().toString());
        //mDateButton.setEnabled(false);

        /*mSolvedCheckBox = (CheckBox)v.findViewById(R.id.Location_solved);
        mSolvedCheckBox.setChecked(mLocation.isSolved());
        mSolvedCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                mLocation.setSolved(isChecked);
            }
        });*/

        return v;
    }
}
