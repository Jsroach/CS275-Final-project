package com.example.criminalintent;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CrimeLab {
    private static CrimeLab sCrimeLab;
    private List<Crime> mCrimes;


    public static CrimeLab get(Context context) {
        if (sCrimeLab == null) {
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }

    private CrimeLab(Context context) {
        mCrimes = new ArrayList<>();

        String[] crimes = {"Robbery", "Robbery", "Robbery", "Robbery", "Assault with Deadly Weapon", "Kidnapping", "Robbery"
                , "Robbery", "Robbery", "Rape", "Assault with Deadly Weapon", "Rape", "Robbery", "Robbery", "Rape", "Rape"
                , "Assault with Deadly Weapon"};

        String[] dates = {"06/03/2019", "08/21/2019", "09/05/2019", "04/27/2019",
                "06/09/2019", "05/24/2019", "08/02/2019"
                , "06/28/2019", "07/28/2019", "08/16/2019", "08/03/2019", "04/07/2019",
                "04/10/2019", "09/15/2019", "08/17/2019", "05/26/2019"
                , "10/28/1996"};
        String[] longitude = {"118.2437", "118.2437", "118.2437", "118.2437",
                "118.2437", "118.2437", "118.2437", "118.2437",
                "118.2437", "118.2437", "118.2437", "118.2437",
                "118.2437", "118.2437", "118.2437", "118.2437",
                "118.2437"};
        String[] latitude = {"34.0522", "34.0522", "34.0522", "34.0522",
                "34.0522", "34.0522", "34.0522"
                , "34.0522", "34.0522", "34.0522", "34.0522", "34.0522",
                "34.0522", "34.0522", "34.0522", "34.0522"
                , "34.0522"};

        String[] weapon = {"Strong-Arm", "Strong-Arm", "Knife", "Strong-Arm",
                "Hand Gun", "Strong-Arm", "Semi-Automatic Pistol"
                , "Strong-Arm", "Strong-Arm", "Strong-Arm", "Strong-Arm", "Strong-Arm",
                "Hand Gun", "Strong-Arm", "Strong-Arm", "Strong-Arm"
                , "Hammer"};

        for (int i = 0; i < crimes.length; i++) {
            Crime crime = new Crime();
            crime.setCrimeNumber("Crime Number: " + i);
            crime.setTitle("Crime Type: " + crimes[i]);
            crime.setDate("Time of Occurrence: " + dates[i]);
            crime.setWeapon("Weapon:  " + weapon[i]);
            crime.setXCoordinate("Longitude: " + longitude[i]);
            crime.setYCoordinate("Latitude:  " + latitude[i]);
            mCrimes.add(crime);
        }
    }



    public List<Crime> getCrimes() {
        return mCrimes;
    }

    public Crime getCrime(UUID id) {
        for (Crime crime : mCrimes) {
            if (crime.getId().equals(id)) {
                return crime;
            }
        }
        return null;
    }

}
