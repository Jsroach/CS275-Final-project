package com.example.criminalintent;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public abstract class SecondFragmentActivity extends AppCompatActivity
{
    protected abstract Fragment createFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_item);
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragmentTwo = fm.findFragmentById(R.id.fragmenttwo_container);
        if (fragmentTwo == null) {
            fragmentTwo = createFragment();
            fm.beginTransaction()
                    .add(R.id.fragmenttwo_container, fragmentTwo)
                    .commit();
        }
    }
/*
    }*/
}
