package com.example.sailboatnavigation;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class LocationLab {
    private static LocationLab sLocationLab;
    private List<Location> mLocations;

    public static LocationLab get(Context context) {
        if (sLocationLab == null) {
            sLocationLab = new LocationLab(context);
        }
        return sLocationLab;
    }
    private LocationLab(Context context) {
        mLocations = new ArrayList<>();


        String[] locations = {"North beach", "Leddy Beach", "Port Kent Docks", "Plattsburgh",
                "Port Douglas Docks","Willsboro Point Docks","Shelburne Bay","Alburgh Port","Montreal Port",
                "Ticonderoga Port",
                "Basin Harbor",
                "Crown Point Harbor",
                "Port Henry Docks"};

        String[] towns = {"Burlington", "Burlington", "Chesterfield", "Plattsburgh",
                "Chesterfield","Willsboro","Shelburne","Alburgh","Montreal",
                "Ticonderoga",
                "Vergennes",
                "Crown point",
                "Port Henry"};
        String[] longitude = {"73.2404", "73.2526", "73.4090", "73.4529",
                "73.4179", "73.3782", "73.2281", "73.3002","73.5673","73.363958",
                "73.4371","73.4598","73.4235"};
        String[] latitude = {"44.4927", "44.5016", "44.5265", "44.6995",
                "44.4859", "44.4087", "44.4193", "44.9751","45.5017","43.8487","44.196205","43.9503","44.0484"};

        String[] yourLatitude = {"44.5257"};
        String[] yourLongitude = {"73.2637"};

        String[] description = {"a nice place to get a tan", "not as nice as North Beach but free parking",
                "Port Kent, New York is a hamlet within the town of Chesterfield, Essex County, New York on the western shore of Lake Champlain.[1]\n" +
                        "Seasonal ferry service to Burlington, Vermont is provided by the Lake Champlain Transportation Company. The community has an Amtrak railroad stop for seasonal service between Montreal and New York City as well.[2]", "Plattsburgh is a city in and the seat of Clinton County, New York, United States. The population was 19,989 at the 2010 census.[1] The population of the unincorporated areas within the surrounding (and separately incorporated) Town of Plattsburgh was 11,870 as of the 2010 census, making the combined population for all of Plattsburgh to be 31,859. Plattsburgh lies just to the northeast of Adirondack Park, immediately outside of the park boundaries.",
                "Chesterfield is a town in Essex County, New York, United States. The population was 2,445 at the 2010 census.[3] The name possibly is from a location in New England." +
                        "Chesterfield is in the northeasternmost part of the county and is 13 miles (21 km) west of Burlington, Vermont (by ferry), 16 mi (26 km) south of Plattsburgh, 77 mi (124 km) south of Montreal, Quebec, and 144 mi (232 km) north of Albany.[4]s","Willsboro is a town in Essex County, New York, in the United States, and lies 30 miles (48 km) south of the city of Plattsburgh. As of the 2010 census, the town population was 2,025.[4] The town is named after early landowner William Gilliland.",
                "This park is dog friendly but leashes are required at all times. " +
                        "A 104 acre park located off of Bay Road. One entrance accesses the Bike and Recreation Path open for walking, snowshoeing and cross-country skiing. The other accesses the boat ramp area managed by the Fish and Wildlife Department. The Recreation Path also connects with the Ti-Haul Trail across Bay Road from the parking lot. The trail is just over a mile long and connects to Harbor Road, just west of the Shelburne Community School.","Alburgh (formerly Alburg) is a town in Grand Isle County, Vermont, United States, founded in 1781 by Ira Allen. The population was 1,998 at the 2010 United States Census.[3] Alburgh is on the Alburgh Tongue, a peninsula extending from Canada into Lake Champlain, and lies on the only road-based route across Lake Champlain to New York state north of Addison, Vermont.",
                "iMontreal (/ˌmʌntriˈɔːl/ (About this soundlisten) MUN-tree-AWL; officially Montréal, French: [mɔ̃ʁeal] (About this soundlisten)) is the most populous municipality in the Canadian province of Quebec and the second-most populous municipality in Canada. Originally called Ville-Marie, or \"City of Mary\",[14] it is named after Mount Royal,[15] the triple-peaked hill in the heart of the city. The city is centred on the Island of Montreal, which took its name from the same source as the city,[16][17] and a few much smaller peripheral islands, the largest of which is Île Bizard",
                "Ticonderoga (/taɪkɒndəˈroʊɡə/) is a town in Essex County, New York, United States. The population was 5,042 at the 2010 census.[3] The name comes from the Mohawk tekontaró:ken, meaning \"it is at the junction of two waterways\".[4]\n" +
                        "\n" +
                        "The Town of Ticonderoga is in the southeastern corner of the county and is south of Plattsburgh.",
                        "When Ardelia Beach, founder of the landmark Basin Harbor Club, first came to Vermont to establish a working farm that would take in summer boarders anxious to escape urban living, she could not have chosen a better locale. Unofficially described as Vermont’s West Coast, Lake Champlain is the sixth-largest lake in America, with more than 600 miles of shoreline bordering its 120-mile length. Since the farmhouse’s creation in 1886, Beach’s vision has evolved into a 700-acre resort including 77 distinctive cottages, many of which offer fireplaces, decks and views of the Adirondack Mountains and Lake Champlain.\n"

                        ,"Crown Point is a town in Essex County, New York, United States, located on the west shore of Lake Champlain. The population was 2,024 at the 2010 census.[3] The name of the town is a direct translation of the original French name, \"Pointe à la Chevelure\".\n" +
                        "\n" +
                        "The town is on the eastern edge of Essex County. It is 43 miles (69 km) southwest of Burlington, Vermont, 53 miles (85 km) northeast of Queensbury, New York, 120 miles (190 km) south of Montreal, Quebec, and 107 miles (172 km) north of Albany, New York.[4]",
                "Port Henry is a hamlet (and census-designated place) in Essex County, New York, United States. The population was 1,194 at the 2010 census.[3]\n" +
                "Port Henry lies on the east side of the town of Moriah and is approximately one hour's drive (52 miles or 84 km)[4] south of Plattsburgh. It is 44 miles (71 km) by road south-southwest of Burlington, Vermont, 115 miles (185 km) north of Albany, New York, and 113 miles (182 km) south of Montreal, Quebec.[4]"};



        for (int i = 0; i < locations.length; i++) {
            Location location = new Location();
            location.setLocationNumber("Destination Number: "+i);
            location.setTitle("Destination: "+locations[i]+", " + towns[i]);
            //location.setDate("Town: "+towns[i]);
            location.setWeapon("Description:  "+description[i]);
            location.setXCoordinate("Longitude: "+longitude[i]);
            location.setYCoordinate("Latitude:  "+latitude[i]);
            //location.setSolved(i % 2 == 0);// Every other one
            double lat =(Double.parseDouble(yourLatitude[0])-Double.parseDouble(latitude[i]));
            double LatMile=lat*69.2;
            double longit =69.2*(Double.parseDouble(yourLongitude[0])/Math.cos(Math.toRadians(Double.parseDouble(yourLatitude[0])))
                    -Double.parseDouble(longitude[i])/Math.cos(Math.toRadians(Double.parseDouble(latitude[i]))));
            double dist = Math.sqrt(Math.pow(lat, 2)+Math.pow(longit,2));

            location.setDistance("Distance: "+dist+" miles");
            mLocations.add(location);
        }

    }



    public List<Location> getLocations() {
        return mLocations;
    }

    public Location getLocation(UUID id) {
        for (Location location : mLocations) {
            if (location.getId().equals(id)) {
                return location;
            }
        }
        return null;
    }
}
