package com.example.criminalintent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public abstract class SingleFragmentActivity extends AppCompatActivity
        {
    protected abstract Fragment createFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragmentOne = fm.findFragmentById(R.id.fragment_container);
        if (fragmentOne == null) {
            fragmentOne = createFragment();
            fm.beginTransaction()
                .add(R.id.fragment_container, fragmentOne)
                .commit(); }
    }

            public void toDefense(View view)
            {
                Intent intent = new Intent(SingleFragmentActivity.this, ItemListActivity.class);
                startActivity(intent);
            }
/*    protected abstract FragmentTwo createFragmentTwo();
    protected void onCreateTwo(Bundle savedInstanceStateTwo) {
        super.onCreate(savedInstanceStateTwo);
        setContentView(R.layout.activity_fragment);
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragmentTwo = fm.findFragmentById(R.id.fragment_container);
        if (fragmentTwo == null) {
            fragmentTwo = createFragment();
            fm.beginTransaction()
                    .add(R.id.fragment_container, fragmentTwo)
                    .commit(); }
    }*/
}
