package com.example.sailboatnavigation;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LocationListFragment extends Fragment {

    private RecyclerView mLocationRecyclerView;
    private LocationAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_location_list, container, false);
        mLocationRecyclerView = (RecyclerView) view
                .findViewById(R.id.Location_recycler_view);
        mLocationRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUI();
        return view;
    }

    @Override public void onResume() {
        super.onResume();
        updateUI();
    }

    private void updateUI() {
        LocationLab locationLab = LocationLab.get(getActivity());
        List<Location> locations = locationLab.getLocations();
        if (mAdapter == null) {
        mAdapter = new LocationAdapter(locations);
        mLocationRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.notifyDataSetChanged();
        }
    }

    private class LocationHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener{
        private Location mLocation;

        private TextView mTitleTextView;
        private TextView mDateTextView;

        public LocationHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_location, parent, false));
            itemView.setOnClickListener(this);


            mTitleTextView = (TextView) itemView.findViewById(R.id.Location_title);
            mDateTextView = (TextView) itemView.findViewById(R.id.Location_date);
        }

        public void bind(Location Location) {
            mLocation = Location;
            mTitleTextView.setText(mLocation.getTitle());
            mDateTextView.setText(mLocation.getDate());
        }

        @Override
        public void onClick(View view) {
            Intent intent = LocationActivity.newIntent(getActivity(), mLocation.getId());
            startActivity(intent);
        }
    }

    private class LocationAdapter extends RecyclerView.Adapter<LocationHolder> {
        private List<Location> mLocations;
        public LocationAdapter(List<Location> Locations) {
            mLocations = Locations;
        }

        @Override
        public LocationHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new LocationHolder(layoutInflater, parent);
        }
        @Override
        public void onBindViewHolder(LocationHolder holder, int position) {
            Location Location = mLocations.get(position);
            holder.bind(Location);
        }

        @Override
        public int getItemCount() {
            return mLocations.size();
        }
    }

}
