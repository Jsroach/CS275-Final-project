package com.example.criminalintent;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ItemLab {
    private List<Item> mDefense;
    private static ItemLab sItemLab;

    public static ItemLab getItem(Context context) {
        if (sItemLab == null) {
            sItemLab = new ItemLab(context);
        }
        return sItemLab;
    }

    private ItemLab(Context context) {
        mDefense = new ArrayList<>();

        String[] defenseItems = {"Motion Sensor", "Bat", "Taser", "Door Jam", "Hand Gun", "Shotgun", "Rifle"
                , "Pepper Spray", "Burglar Bars", "Knife", "Bulletproof Vest", "Cameras", "Trip Wire", "Dog", "Bear Trap", "Sirens"
                , "Security System"};

        String[] price = {"$10", "$20", "$20", "$100",
                "$500", "$400", "$600"
                , "$40", "$250", "$20", "$300", "$1,000",
                "$50", "$100", "$60", "$30"
                , "$1,000"};

        for (int i = 0; i < defenseItems.length; i++) {
            Item item = new Item();
            item.setItemNumber("Item Number: " + i);
            item.setTitle("Defense Items: " + defenseItems[i]);
            item.setPrice("Price: " + price[i]);
            mDefense.add(item);
        }

    }

    public List<Item> getItems() {
        return mDefense;
    }

    public Item getItem(UUID id) {
        for (Item item : mDefense) {
            if (item.getId().equals(id)) {
                return item;
            }
        }
        return null;
    }

}
