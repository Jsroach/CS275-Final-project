package com.example.criminalintent;

import java.util.UUID;

public class Item {

        private UUID mId;
        private String mTitle;
        private String mPrice;
        private String mItemNumber;

        public Item() {
            mId = UUID.randomUUID();
            mPrice = new String();
        }

        public UUID getId() {
            return mId;
        }
        public String getTitle() {
            return mTitle;
        }
        public void setTitle(String title) {
            mTitle = title;
        }
        public String getPrice() {
            return mPrice;
        }
        public void setPrice(String price) {
            mPrice = price;
        }
        public String getItemNumber() {
        return mItemNumber;
    }
        public void setItemNumber(String itemNumber) {
        mItemNumber = itemNumber;
    }
    }






