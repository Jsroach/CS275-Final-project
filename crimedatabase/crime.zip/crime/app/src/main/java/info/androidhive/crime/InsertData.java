package info.androidhive.crime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import info.androidhive.checkinternet.R;

public class InsertData extends AppCompatActivity
{

    EditText text1,text2,text3,text4,text5;
    Button insertData;
    DatabaseHelper db = new DatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_data);

        text1 = (EditText)findViewById(R.id.text1);
        text2 = (EditText)findViewById(R.id.text2);

        text3 = (EditText)findViewById(R.id.text3);

        text4 = (EditText)findViewById(R.id.text4);

        text5 = (EditText)findViewById(R.id.text5);

        insertData = (Button)findViewById(R.id.insertData);

        insertData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean insertData = db.insertCrimeReportData(text1.getText().toString(),text2.getText().toString(),text3.getText().toString(),text4.getText().toString(),text5.getText().toString());
                clearText();
                 if(insertData == true)
                 {

                     Toast.makeText(InsertData.this, "Data save successfully", Toast.LENGTH_SHORT).show();

                 }
                 else
                 {
                     Toast.makeText(InsertData.this, "Data not save successfully", Toast.LENGTH_SHORT).show();

                 }

            }
        });

    }

    public void clearText()
    {
        text1.getText().clear();
        text2.getText().clear();
        text3.getText().clear();
        text4.getText().clear();
        text5.getText().clear();

    }
}
