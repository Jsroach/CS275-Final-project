package com.example.sailboatnavigation;

import java.util.UUID;

public class Location {
    private UUID mId;
    private String mTitle;
    private String mDate;
    private String mLocationNumber;
    private String mXCoordinate;
    private String mYCoordinate;
    private String mWeapon;
    private String mDistance;
    private boolean mSolved;
    public Location() {
        mId = UUID.randomUUID();
        mDate = new String();
    }

    public UUID getId() {
        return mId;
    }
    public String getTitle() {
        return mTitle;
    }
    public void setTitle(String title) {
        mTitle = title;
    }
    public String getDate() {
        return mDate;
    }
    public void setDate(String date) {
        mDate = date;
    }
    public String getLocationNumber() {
        return mLocationNumber;
    }
    public void setLocationNumber(String LocationNumber) {
        mLocationNumber = LocationNumber;
    }
    public String getXCoordinate() {
        return mXCoordinate;
    }
    public void setXCoordinate(String xCoordinate) {
        mXCoordinate = xCoordinate;
    }
    public String getYCoordinate() {
        return mYCoordinate;
    }
    public void setYCoordinate(String yCoordinate) {
        mYCoordinate = yCoordinate;
    }
    public String getWeapon() {
        return mWeapon;
    }
    public void setWeapon(String weapon) {
        mWeapon = weapon;
    }
    public String getDistance() {
        return mDistance;
    }
    public void setDistance(String distance) {
        mDistance = distance;
    }
    public boolean isSolved() {
        return mSolved;
    }
    public void setSolved(boolean solved) {
        mSolved = solved;
    }
}
