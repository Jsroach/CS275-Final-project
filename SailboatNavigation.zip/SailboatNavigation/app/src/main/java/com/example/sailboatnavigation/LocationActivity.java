package com.example.sailboatnavigation;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import java.util.UUID;

public class LocationActivity extends SingleFragmentActivity {

    public static final String EXTRA_Location_ID =
            "com.bignerdranch.android.criminalintent.Location_id";
    public static Intent newIntent(Context packageContext, UUID LocationId) {
        Intent intent = new Intent(packageContext, LocationActivity.class);
        intent.putExtra(EXTRA_Location_ID, LocationId);
        return intent;
    }

    @Override
    protected Fragment createFragment() {

        UUID LocationId = (UUID) getIntent()
                .getSerializableExtra(EXTRA_Location_ID);
        return LocationFragment.newInstance(LocationId);
    }
}
