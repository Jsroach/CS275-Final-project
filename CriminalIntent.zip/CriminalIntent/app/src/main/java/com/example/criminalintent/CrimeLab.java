package com.example.criminalintent;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CrimeLab {
    private static CrimeLab sCrimeLab;
    private List<Crime> mCrimes;

    public static CrimeLab get(Context context) {
        if (sCrimeLab == null) {
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }
    private CrimeLab(Context context) {
        mCrimes = new ArrayList<>();

        String[] crimes = {"There's", "a", "lady", "who's","sure", "all","that"
                ,"glitters","is","gold","and","she's","buying","a","stairway","to"
                ,"heaven"};

        String[] dates = {"10/28/1996", "10/28/1996", "10/28/1996", "10/28/1996",
                "10/28/1996", "10/28/1996","10/28/1996"
                ,"10/28/1996","10/28/1996","10/28/1996","10/28/1996","10/28/1996",
                "10/28/1996","10/28/1996","10/28/1996","10/28/1996"
                ,"10/28/1996"};
        String[] longitude = {"118.2437", "118.2437", "118.2437", "118.2437",
                "118.2437", "118.2437","118.2437", "118.2437",
                "118.2437", "118.2437","118.2437", "118.2437",
                "118.2437", "118.2437","118.2437", "118.2437",
                "118.2437"};
        String[] latitude = {"34.0522", "34.0522", "34.0522", "34.0522",
                "34.0522", "34.0522","34.0522"
                ,"34.0522","34.0522","34.0522","34.0522","34.0522",
                "34.0522","34.0522","34.0522","34.0522"
                ,"34.0522"};

        String[] weapon = {"chainsaw", "axe", "pistol", "large rock",
                "lightsaber", "flamethrower","rubber duck"
                ,"bible verses","drywall slab","rope","candlestick","anvil",
                "chandelier","Shrek DVD set","Jason Hibbeler's glasses","R2D2"
                ,"carcinogens"};

        for (int i = 0; i < crimes.length; i++) {
            Crime crime = new Crime();
            crime.setCrimeNumber("Crime Number: "+i);
            crime.setTitle("Crime Type: "+crimes[i]);
            crime.setDate("Time of Occurrence: "+dates[i]);
            crime.setWeapon("Weapon:  "+weapon[i]);
            crime.setXCoordinate("Longitude: "+longitude[i]);
            crime.setYCoordinate("Latitude:  "+latitude[i]);
            crime.setSolved(i % 2 == 0);// Every other one
            mCrimes.add(crime);
        }

    }



    public List<Crime> getCrimes() {
        return mCrimes;
    }

    public Crime getCrime(UUID id) {
        for (Crime crime : mCrimes) {
            if (crime.getId().equals(id)) {
                return crime;
            }
        }
        return null;
    }
}
