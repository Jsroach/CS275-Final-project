package com.example.criminalintent;
import androidx.fragment.app.Fragment;

public class ItemListActivity extends SecondFragmentActivity {
@Override
    protected Fragment createFragment() {
        return new ItemListFragment();
    }
    //@Override
    /*protected Fragment createFragment() {
        return new ItemListFragment();
    }*/


}


