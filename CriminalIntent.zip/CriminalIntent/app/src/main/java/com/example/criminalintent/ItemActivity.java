package com.example.criminalintent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.util.UUID;

    public class ItemActivity extends SecondFragmentActivity {

        public static final String EXTRA_ITEM_ID =
                "com.bignerdranch.android.criminalintent.item_id";
        public static Intent newIntent(Context packageContext, UUID itemId) {
            Intent intent = new Intent(packageContext, com.example.criminalintent.ItemActivity.class);
            intent.putExtra(EXTRA_ITEM_ID, itemId);
            return intent;
        }

@Override
        protected Fragment createFragment() {

            UUID itemId = (UUID) getIntent()
                    .getSerializableExtra(EXTRA_ITEM_ID);
            return ItemFragmentt.newInstance(itemId);
        }
    }

